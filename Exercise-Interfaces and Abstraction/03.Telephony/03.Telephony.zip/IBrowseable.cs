﻿

namespace _03.Telephony
{
    public interface IBrowseable
    {
        public string Browse(string url);
    }
}
